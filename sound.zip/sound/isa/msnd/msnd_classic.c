/* The work is in msnd_pinnacle.c, just define MSND_CLASSIC before it. */
#define MSND_CLASSIC
#include "msnd_pinnacle.c"
